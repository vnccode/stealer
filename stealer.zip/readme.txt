C# stealer Chrome, Opera ,Chromium ,Edge ,Firefox, IE , passwords, cookies , bookmarks , autofill
, vault , Outlook passwords , Filezilla , desktop files ,wallets